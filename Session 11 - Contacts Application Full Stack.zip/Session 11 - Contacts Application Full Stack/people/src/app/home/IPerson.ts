export interface IPerson {
    id: number;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    }
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { IPerson } from './IPerson';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  saveUnsuccessful: boolean;
  id: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  people: IPerson[] = [];


  constructor(public httpClient: HttpClient) {

  }


  onFormSubmit(ngForm: NgForm) {
    this.saveUnsuccessful = false;

    if (!ngForm.valid) {
      this.saveUnsuccessful = true;
      return;
    }

    console.log(ngForm);


    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        "Accept": 'application/json'
      })
    };

    const data = {
      id: this.id,
      firstName: this.firstName,
      lastName: this.lastName,
      phoneNumber: this.phoneNumber
    };

    this.httpClient.post<any>("http://localhost:3000", data, options)
      .subscribe({
        next: () => {
          console.log("Call successful");
        },
        error: (err) => {
          console.error("Error occured: " + JSON.stringify(err));
        }
      });

    ngForm.resetForm();
  }

  getData() {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        "Accept": 'application/json'
      })
    };

    this.httpClient.get<any>("http://localhost:3000", options)
      .subscribe({
        next: (data) => {
          console.log(data);
          this.people = data;
        },
        error: (err) => {
          console.error("Error occurred: " + err);
        }
      });
  }

}

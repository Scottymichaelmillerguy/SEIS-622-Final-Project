import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'class-demo';

  constructor(public router: Router) {

  }


  loadContact() {
    this.router.navigate(['contact', '1'], {queryParams: {food: 'strawberry', dogName: 'Hector'}} );
    //this.router.navigateByUrl('/contact/1');
  }
}

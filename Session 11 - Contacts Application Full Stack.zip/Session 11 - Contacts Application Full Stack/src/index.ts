const express = require("express");
const port = 3000;
const app = express();
const path = require("path");
const fs = require("fs");
const filePath = path.join(__dirname, "people.json");
const bodyParser = require("body-parser");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.text());

const cors = require("cors");
let corsOptions = {
    origin: ['http://localhost:5500']
}
app.use(cors());

import { IPerson } from './IPerson.ts';

let contactList: IPerson[] = [];

fs.readFile(filePath, (err: any, data: any) => {
    if (err) {
        console.error("Unable to read file: " + filePath);
    } else {
        contactList = JSON.parse(data)
    }
});

// with express, you define the handler for routes.
app.get("/", (req, resp) => {
    resp.status(200);
    return resp.json(contactList);
});

// Return a person based on id.
app.get("/:id", (req, resp) => {
    const person = contactList.find(c => c.id == req.params.id);
    if (person) {
        resp.status(200);
        return resp.json(person);
    }
    resp.status(404);
    return resp.json({ error: `Person with id: ${req.params.id} not found.` });
});

app.post("/", (req, res) => {
    const {id, firstName, lastName, phoneNumber} = req.body;
    
    if (!id || !firstName || !lastName || !phoneNumber) {
        return res.status(400).json({error: 'All fields are required' });
    }

    const newPerson = {
        id,
        firstName,
        lastName,
        phoneNumber
    };
    
    contactList.push(newPerson);

    res.status(201).json({ message: 'Contact added successfully', contact: newPerson })
});

app.put('/:id', (req, res) => {
    const { id } = req.params;
    const { firstName, lastName, phoneNumber } = req.body;
    const person = contactList.find(c => c.id === parseInt(id));
    
    if (!person) {
        return res.status(404).json({ message: 'Person not found'});
    }
    if (firstName) person.firstName = firstName;
    if (lastName) person.lastName = lastName;
    if (phoneNumber) person.phoneNumber = phoneNumber;
    console.log(`Person updated successfully ${JSON.stringify(person)}`);
    return res.json({message: 'Person updated', person});
    
});

app.delete('/:id', (req, res) => {
    const { id } = req.params;

    const person = contactList.findIndex(c => c.id === parseInt(id));
    
    if (person === -1) {
        return res.status(404).json({ message: 'Person not found'});
    }

    //Remove the person from the list
    contactList.splice(person, 1);
    console.log(`Person deleted successfully `);
    
    res.status(200).json({ message: 'Person deleted successfully' });
});

app.listen(port, () => {
    console.log(`Example express file server listening on port ${port}`);
});